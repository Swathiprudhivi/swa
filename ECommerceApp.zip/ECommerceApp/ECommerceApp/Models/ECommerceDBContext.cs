﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ECommerceApp.Models
{
    public class ECommerceDBContext : DbContext
    {
        public ECommerceDBContext()
        {
        }


        public ECommerceDBContext(DbContextOptions<ECommerceDBContext> options)
            : base(options)
        {
        }


        public DbSet<User> User { get; set; }





        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Data Source=JRDOTNETFSECO-3;Initial Catalog=ECommerce;Persist Security Info=True;User ID=sa;Password=pass@word1");
        }
    }
}
